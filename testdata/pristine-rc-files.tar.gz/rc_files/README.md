# rc_files - Test Fixtures for Shell Configuration

This directory contains realistic but controlled copies of shell rc files (`.zshrc`, `.bashrc`, `config.fish`, `.profile`, etc.).

## Purpose

These fixtures are used by tests to verify the shell integration logic in odin-doctor, including:

- Detecting existing ODIN_ROOT settings
- Inserting or updating the `# MANAGED BY ODIN-UPDATE` marker
- Commenting out old/stale Odin configuration blocks
- Adding correct `export` / `set -gx` lines for the current installation
- Handling different shells (zsh, bash, fish)
- Preserving user customizations outside the managed block

## Why fixtures?

All tests that touch shell configuration **must** use temporary directories + copies of these files. This ensures:

- Tests never modify the developer's real rc files
- Behavior is reproducible across machines and CI
- We can exercise every edge case (clean, old unmanaged, already managed correct/wrong, mixed, etc.)

## Usage in tests

Typical pattern (in test code):

1. Create a temp directory.
2. Copy the desired fixture into it (e.g. as `.zshrc` or `config.fish`).
3. Run the relevant odin-doctor logic (or the built binary) pointing at the temp location.
4. Read the modified file back and assert the expected state (marker present, correct path, old lines commented, etc.).
5. Clean up.

## File naming convention

- `<shell>_<state>.ext` or descriptive (e.g. `zshrc_already_managed_wrong_path`)
- Keep files without leading dot so they are easy to manage in git and when copying.

## Adding new fixtures

When you need to test a new scenario (e.g. a very long rc file, specific escape sequences, multiple previous Odin blocks), add a new file here and reference it from the test.

Do not put real user configuration or secrets in these files.
